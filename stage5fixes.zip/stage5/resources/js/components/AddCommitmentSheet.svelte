<script lang="ts">
    /**
     * لوح إضافة التزام — إعادة بناء بعد ملاحظات الاختبار.
     *
     * ما تغيّر ولماذا:
     *   • **زر الحفظ مثبّت أسفل اللوح** ولا يتحرّك مع التمرير — كان في نهاية
     *     نموذج طويل فلا يراه المستخدم أصلاً.
     *   • **رسائل الخطأ تحت الحقل المعني**، ولا تظهر إلا بعد لمس الحقل أو بعد
     *     محاولة الحفظ — لا لوحة حمراء أسفل الصفحة قبل أن يكتب المستخدم شيئاً.
     *   • **القسط الشهري يكتبه المستخدم** — يُقترح عليه ناتج القسمة كنقطة بداية
     *     فقط، لأن الأقساط الواقعية فيها رسوم وفوائد ودفعة أولى، فلا تساوي
     *     المبلغ ÷ الأشهر بالضرورة.
     *   • **الاستحقاق خياران فقط**: مع الراتب · يوم من الشهر — واختيار اليوم
     *     يعرض فوراً أنه سيظهر في التقويم المالي.
     *   • **التنبيه خيار واحد** لا ثلاثة معاً.
     */
    import CalendarDays from 'lucide-svelte/icons/calendar-days';
    import Check from 'lucide-svelte/icons/check';
    import Hand from 'lucide-svelte/icons/hand';
    import Info from 'lucide-svelte/icons/info';
    import TriangleAlert from 'lucide-svelte/icons/triangle-alert';
    import X from 'lucide-svelte/icons/x';
    import Zap from 'lucide-svelte/icons/zap';
    import AmountInput from '@/components/AmountInput.svelte';
    import CategoryIcon from '@/components/CategoryIcon.svelte';
    import { formatAmount, formatCurrency } from '@/lib/format';
    import {
        type CommitmentKind,
        type DueType,
        type NotifyWhen,
        type PaymentMethod,
        finishLabel,
        KIND_COLOR,
        KIND_ICON,
        KIND_LABEL,
        KIND_ORDER,
        monthlyOf,
        NOTIFY_LABEL,
    } from '@/lib/commitments';

    let {
        open = $bindable(false),
        income = 0,
        currentObligations = 0,
        salaryDay = 27,
        processing = false,
        onSave,
    }: {
        open?: boolean;
        income?: number;
        currentObligations?: number;
        salaryDay?: number;
        processing?: boolean;
        onSave?: (payload: Record<string, unknown>) => void;
    } = $props();

    let kind = $state<CommitmentKind>('bill');
    let name = $state('');
    let amount = $state(0); // هللات — للأقساط: المبلغ الكامل
    let monthlyAmount = $state(0); // هللات — القسط الشهري كما يكتبه المستخدم
    let monthlyTouched = $state(false);
    let months = $state(12);
    let isVariable = $state(false);
    let paymentMethod = $state<PaymentMethod>('manual');
    let dueType = $state<DueType>('month_day');
    let dueDay = $state(1);
    let notifyWhen = $state<NotifyWhen>('before_3');
    let reserve = $state(true);

    /** الحقول التي لمسها المستخدم — لا نُظهر خطأ حقل لم يصله بعد. */
    let touched = $state<Record<string, boolean>>({});
    let submitted = $state(false);

    const isInstallment = $derived(kind === 'installment');

    /** الاقتراح الآلي: نقطة بداية فقط، والمستخدم يعدّله بحرية. */
    const suggestedMonthly = $derived(monthlyOf(amount, months));

    // ما دام المستخدم لم يلمس حقل القسط، نبقيه مطابقاً للاقتراح.
    $effect(() => {
        if (isInstallment && !monthlyTouched) monthlyAmount = suggestedMonthly;
    });

    const effectiveMonthly = $derived(isInstallment ? monthlyAmount : amount);
    const shareOfIncome = $derived(income > 0 ? (effectiveMonthly / income) * 100 : 0);
    const totalAfter = $derived(currentObligations + effectiveMonthly);

    /** فرق مجموع الأقساط عن المبلغ الكامل — معلومة لا خطأ (رسوم/فوائد). */
    const installmentGap = $derived(isInstallment && monthlyAmount > 0 ? monthlyAmount * months - amount : 0);

    // ── أخطاء لكل حقل على حدة ─────────────────────────────────────────
    const fieldErrors = $derived.by(() => {
        const e: Record<string, string> = {};
        if (!name.trim()) e.name = 'الاسم مطلوب — بدونه لن تعرف الالتزام في القائمة.';
        if (!isVariable && amount <= 0) e.amount = isInstallment ? 'أدخل المبلغ الكامل للقسط.' : 'أدخل المبلغ.';
        if (isInstallment) {
            if (months < 2) e.months = 'شهران على الأقل.';
            else if (months > 480) e.months = 'عدد الأشهر كبير جداً.';
            if (monthlyAmount <= 0) e.monthly = 'أدخل قيمة القسط الشهري.';
        }
        if (dueType === 'month_day' && (dueDay < 1 || dueDay > 31)) e.dueDay = 'اختر يوماً بين 1 و 31.';
        return e;
    });

    /** يظهر الخطأ فقط بعد لمس الحقل أو بعد الضغط على «حفظ». */
    function errorFor(field: string): string {
        return submitted || touched[field] ? (fieldErrors[field] ?? '') : '';
    }

    function touch(field: string) {
        touched = { ...touched, [field]: true };
    }

    /** المنع الوحيد في الصفحة: قسط يجعل الالتزامات تفوق الدخل. */
    const blocked = $derived(isInstallment && income > 0 && totalAfter > income);

    const warning = $derived.by(() => {
        if (blocked || income <= 0) return null;
        if (totalAfter > income * 0.7)
            return `التزاماتك بعد الإضافة ${Math.round((totalAfter / income) * 100)}٪ من دخلك — فوق 70٪ يترك مجالاً ضيقاً للمصاريف.`;
        if (isInstallment && shareOfIncome > 30)
            return `القسط وحده ${Math.round(shareOfIncome)}٪ من دخلك. تقدر تمدّه على أشهر أكثر.`;
        return null;
    });

    const canSave = $derived(!processing && Object.keys(fieldErrors).length === 0 && !blocked);

    /** يوم الاستحقاق كما سيظهر في التقويم المالي. */
    const dueHint = $derived(
        dueType === 'salary_day'
            ? `يتحرّك مع راتبك — اليوم ${salaryDay} من كل شهر`
            : `يظهر في التقويم المالي يوم ${dueDay} من كل شهر`,
    );

    function reset() {
        kind = 'bill';
        name = '';
        amount = 0;
        monthlyAmount = 0;
        monthlyTouched = false;
        months = 12;
        isVariable = false;
        paymentMethod = 'manual';
        dueType = 'month_day';
        dueDay = 1;
        notifyWhen = 'before_3';
        reserve = true;
        touched = {};
        submitted = false;
    }

    function submit() {
        submitted = true;
        if (!canSave) return;

        onSave?.({
            kind,
            name: name.trim(),
            amount: isInstallment ? monthlyAmount : isVariable ? null : amount,
            monthly_amount: isInstallment ? monthlyAmount : null,
            total_amount: isInstallment ? amount : 0,
            months_count: isInstallment ? months : 0,
            is_variable: isVariable,
            payment_method: paymentMethod,
            due_type: dueType,
            due_day: dueType === 'month_day' ? dueDay : null,
            notify_when: notifyWhen,
            reserve_in_budget: reserve,
        });
        reset();
    }

    function close() {
        open = false;
        reset();
    }

    function onKeydown(e: KeyboardEvent) {
        if (e.key === 'Escape' && open) close();
    }

    const DAYS = Array.from({ length: 31 }, (_, i) => i + 1);
</script>

<svelte:window on:keydown={onKeydown} />

{#if open}
    <div class="fixed inset-0 z-50 flex items-end justify-center md:items-center">
        <button type="button" class="absolute inset-0 bg-black/45" aria-label="إغلاق" onclick={close}></button>

        <div
            role="dialog"
            aria-modal="true"
            aria-label="إضافة التزام"
            class="relative flex max-h-[92vh] w-full flex-col rounded-t-3xl bg-card shadow-lg md:max-w-md md:rounded-3xl"
        >
            <!-- الرأس الثابت -->
            <div class="shrink-0 px-4 pt-2 pb-3">
                <div class="mx-auto mb-3 h-1 w-9 rounded-full bg-border md:hidden"></div>
                <div class="flex items-center justify-between gap-2">
                    <h2 class="text-[15px] font-semibold">إضافة التزام</h2>
                    <button
                        type="button"
                        onclick={close}
                        aria-label="إغلاق"
                        class="inline-flex size-9 items-center justify-center rounded-xl border border-input text-muted-foreground"
                    >
                        <X class="size-4" />
                    </button>
                </div>
            </div>

            <!-- المحتوى القابل للتمرير -->
            <div class="min-h-0 flex-1 overflow-y-auto px-4 pb-3">
                <!-- النوع -->
                <div class="grid grid-cols-4 gap-1.5">
                    {#each KIND_ORDER as k (k)}
                        <button
                            type="button"
                            aria-pressed={kind === k}
                            onclick={() => (kind = k)}
                            class="flex min-h-[68px] flex-col items-center justify-center gap-1.5 rounded-2xl border transition-colors {kind ===
                            k
                                ? 'border-2 border-current'
                                : 'border-border'}"
                            style={kind === k ? `color:${KIND_COLOR[k]}` : ''}
                        >
                            <CategoryIcon icon={KIND_ICON[k]} color={KIND_COLOR[k]} size="sm" />
                            <span class="text-[11px] {kind === k ? 'font-semibold text-foreground' : 'text-muted-foreground'}">
                                {KIND_LABEL[k]}
                            </span>
                        </button>
                    {/each}
                </div>

                <!-- المبلغ -->
                <div class="mt-4">
                    {#if isVariable}
                        <p class="rounded-xl border border-dashed border-input bg-secondary px-3 py-3 text-center text-[12px] text-muted-foreground">
                            المبلغ يُسجَّل عند الدفع كل شهر — لا حاجة لإدخاله الآن
                        </p>
                    {:else}
                        <AmountInput
                            bind:value={amount}
                            label={isInstallment ? 'المبلغ الكامل للقسط' : 'المبلغ الشهري'}
                            error={errorFor('amount')}
                        />
                    {/if}
                </div>

                <!-- الاسم -->
                <div class="mt-3">
                    <label for="c-name" class="mb-1.5 block text-[11.5px] font-medium">
                        الاسم <span class="text-destructive">*</span>
                    </label>
                    <input
                        id="c-name"
                        bind:value={name}
                        onblur={() => touch('name')}
                        aria-invalid={!!errorFor('name')}
                        placeholder={kind === 'bill'
                            ? 'كهرباء'
                            : kind === 'rent'
                              ? 'إيجار الشقة'
                              : kind === 'installment'
                                ? 'قسط السيارة'
                                : 'اشتراك جوال'}
                        class="min-h-11 w-full rounded-xl border bg-secondary px-3 text-[13px] outline-none focus:border-primary {errorFor(
                            'name',
                        )
                            ? 'border-destructive'
                            : 'border-input'}"
                    />
                    {#if errorFor('name')}
                        <p class="mt-1 text-[11.5px] text-destructive">{errorFor('name')}</p>
                    {/if}
                </div>

                <!-- الأقساط: عدد الأشهر + القسط الشهري (يكتبه المستخدم) -->
                {#if isInstallment}
                    <div class="mt-3 grid grid-cols-2 gap-2">
                        <div>
                            <label for="c-months" class="mb-1.5 block text-[11.5px] font-medium">عدد الأشهر</label>
                            <input
                                id="c-months"
                                type="number"
                                min="2"
                                max="480"
                                bind:value={months}
                                onblur={() => touch('months')}
                                class="min-h-11 w-full rounded-xl border bg-secondary px-3 text-[13px] tabular-nums outline-none focus:border-primary {errorFor(
                                    'months',
                                )
                                    ? 'border-destructive'
                                    : 'border-input'}"
                            />
                            {#if errorFor('months')}
                                <p class="mt-1 text-[11.5px] text-destructive">{errorFor('months')}</p>
                            {/if}
                        </div>

                        <div>
                            <label for="c-monthly" class="mb-1.5 block text-[11.5px] font-medium">القسط الشهري</label>
                            <input
                                id="c-monthly"
                                type="number"
                                min="0"
                                step="1"
                                value={Math.round(monthlyAmount / 100)}
                                oninput={(e) => {
                                    monthlyTouched = true;
                                    monthlyAmount = Math.round(Number(e.currentTarget.value || 0) * 100);
                                }}
                                onblur={() => touch('monthly')}
                                class="min-h-11 w-full rounded-xl border bg-secondary px-3 text-[13px] font-semibold tabular-nums outline-none focus:border-primary {errorFor(
                                    'monthly',
                                )
                                    ? 'border-destructive'
                                    : 'border-input'}"
                            />
                            {#if errorFor('monthly')}
                                <p class="mt-1 text-[11.5px] text-destructive">{errorFor('monthly')}</p>
                            {:else if !monthlyTouched && suggestedMonthly > 0}
                                <p class="mt-1 text-[10.5px] text-muted-foreground">
                                    مقترح: {formatAmount(suggestedMonthly)} — عدّله لو مختلف
                                </p>
                            {/if}
                        </div>
                    </div>

                    {#if monthlyAmount > 0 && months >= 2}
                        <div class="mt-2 rounded-xl border border-primary/20 bg-primary/6 px-3 py-2.5 text-[12px] text-foreground/85">
                            <p>
                                يخلص في <b class="font-semibold">{finishLabel(months)}</b>
                                {#if income > 0}
                                    · <b class="font-semibold">{Math.round(shareOfIncome)}٪</b> من دخلك
                                {/if}
                            </p>
                            {#if Math.abs(installmentGap) > 100}
                                <p class="mt-1 text-[11px] text-muted-foreground">
                                    مجموع الأقساط {formatAmount(monthlyAmount * months)} مقابل مبلغ
                                    {formatAmount(amount)} — فرق {formatAmount(Math.abs(installmentGap))}
                                    {installmentGap > 0 ? '(رسوم أو فوائد)' : '(دفعة أولى أو خصم)'}.
                                </p>
                            {/if}
                        </div>
                    {/if}
                {:else if kind === 'bill'}
                    <!-- الفاتورة المتغيّرة -->
                    <div class="mt-3 flex items-center gap-3 rounded-xl border border-border bg-secondary px-3 py-2.5">
                        <div class="flex-1">
                            <p class="text-[12.5px] font-medium">المبلغ متغيّر كل شهر</p>
                            <p class="text-[10.5px] text-muted-foreground">نحجز متوسّط آخر 3 أشهر حتى تسجّل الفعلي</p>
                        </div>
                        <button
                            type="button"
                            role="switch"
                            aria-checked={isVariable}
                            aria-label="المبلغ متغيّر"
                            onclick={() => (isVariable = !isVariable)}
                            class="relative h-6 w-11 shrink-0 rounded-full transition-colors {isVariable ? 'bg-success' : 'bg-border'}"
                        >
                            <span
                                class="absolute top-0.5 size-5 rounded-full bg-white shadow transition-[inset-inline-start] {isVariable
                                    ? 'start-[22px]'
                                    : 'start-0.5'}"
                            ></span>
                        </button>
                    </div>
                {/if}

                <!-- طريقة الدفع -->
                <div class="mt-3">
                    <span class="mb-1.5 block text-[11.5px] font-medium">طريقة الدفع</span>
                    <div class="flex gap-2">
                        <button
                            type="button"
                            aria-pressed={paymentMethod === 'auto'}
                            onclick={() => (paymentMethod = 'auto')}
                            class="inline-flex min-h-11 flex-1 items-center justify-center gap-1.5 rounded-xl border px-3 text-[12.5px] {paymentMethod ===
                            'auto'
                                ? 'border-primary bg-primary/8 font-semibold text-primary'
                                : 'border-input text-foreground/85'}"
                        >
                            <Zap class="size-3.5" /> خصم تلقائي
                        </button>
                        <button
                            type="button"
                            aria-pressed={paymentMethod === 'manual'}
                            onclick={() => (paymentMethod = 'manual')}
                            class="inline-flex min-h-11 flex-1 items-center justify-center gap-1.5 rounded-xl border px-3 text-[12.5px] {paymentMethod ===
                            'manual'
                                ? 'border-primary bg-primary/8 font-semibold text-primary'
                                : 'border-input text-foreground/85'}"
                        >
                            <Hand class="size-3.5" /> أدفعه بنفسي
                        </button>
                    </div>
                    <p class="mt-1.5 text-[10.5px] leading-relaxed text-muted-foreground">
                        التلقائي يُسجَّل مدفوعاً وحده يوم الاستحقاق. اليدوي يبقى محجوزاً ويذكّرك.
                    </p>
                </div>

                <!-- موعد الاستحقاق — خياران فقط -->
                <div class="mt-3">
                    <span class="mb-1.5 block text-[11.5px] font-medium">موعد الاستحقاق</span>
                    <div class="grid grid-cols-2 gap-2">
                        <button
                            type="button"
                            aria-pressed={dueType === 'salary_day'}
                            onclick={() => (dueType = 'salary_day')}
                            class="inline-flex min-h-11 items-center justify-center gap-1.5 rounded-xl border px-3 text-[12.5px] {dueType ===
                            'salary_day'
                                ? 'border-primary bg-primary/8 font-semibold text-primary'
                                : 'border-input text-foreground/85'}"
                        >
                            <Zap class="size-3.5" /> مع الراتب
                        </button>
                        <button
                            type="button"
                            aria-pressed={dueType === 'month_day'}
                            onclick={() => (dueType = 'month_day')}
                            class="inline-flex min-h-11 items-center justify-center gap-1.5 rounded-xl border px-3 text-[12.5px] {dueType ===
                            'month_day'
                                ? 'border-primary bg-primary/8 font-semibold text-primary'
                                : 'border-input text-foreground/85'}"
                        >
                            <CalendarDays class="size-3.5" /> يوم محدّد
                        </button>
                    </div>

                    {#if dueType === 'month_day'}
                        <div class="mt-2 flex items-center gap-2">
                            <label for="c-day" class="shrink-0 text-[12px] text-muted-foreground">يوم</label>
                            <select
                                id="c-day"
                                bind:value={dueDay}
                                onblur={() => touch('dueDay')}
                                class="min-h-11 flex-1 rounded-xl border border-input bg-secondary px-3 text-[13px] font-semibold tabular-nums outline-none focus:border-primary"
                            >
                                {#each DAYS as d (d)}
                                    <option value={d}>{d} من كل شهر</option>
                                {/each}
                            </select>
                        </div>
                        {#if errorFor('dueDay')}
                            <p class="mt-1 text-[11.5px] text-destructive">{errorFor('dueDay')}</p>
                        {/if}
                    {/if}

                    <p class="mt-2 inline-flex items-start gap-2 rounded-xl border border-primary/20 bg-primary/6 px-3 py-2 text-[11px] text-foreground/85">
                        <Info class="mt-px size-3.5 shrink-0 text-primary" />
                        {dueHint}
                    </p>
                </div>

                <!-- التنبيه — خيار واحد -->
                <div class="mt-3">
                    <span class="mb-1.5 block text-[11.5px] font-medium">نبّهني</span>
                    <div class="grid grid-cols-3 gap-1.5">
                        {#each ['before_3', 'on_due', 'none'] as w (w)}
                            <button
                                type="button"
                                role="radio"
                                aria-checked={notifyWhen === w}
                                onclick={() => (notifyWhen = w as NotifyWhen)}
                                class="inline-flex min-h-11 items-center justify-center rounded-xl border px-2 text-center text-[11.5px] {notifyWhen ===
                                w
                                    ? 'border-primary bg-primary/8 font-semibold text-primary'
                                    : 'border-input text-foreground/85'}"
                            >
                                {NOTIFY_LABEL[w as NotifyWhen]}
                            </button>
                        {/each}
                    </div>
                </div>

                <!-- الحجز من الميزانية -->
                <div class="mt-3 flex items-center gap-3 rounded-xl border border-border bg-secondary px-3 py-2.5">
                    <div class="flex-1">
                        <p class="text-[12.5px] font-medium">احجزه من ميزانيتي</p>
                        <p class="text-[10.5px] leading-relaxed text-muted-foreground">
                            {#if reserve}
                                ينقص {formatCurrency(effectiveMonthly)} من «المتبقي لك» في اللوحة حتى تدفعه
                            {:else}
                                لن يظهر في «المتبقي لك» — استعمله للالتزامات غير المؤكّدة فقط
                            {/if}
                        </p>
                    </div>
                    <button
                        type="button"
                        role="switch"
                        aria-checked={reserve}
                        aria-label="احجزه من ميزانيتي"
                        onclick={() => (reserve = !reserve)}
                        class="relative h-6 w-11 shrink-0 rounded-full transition-colors {reserve ? 'bg-success' : 'bg-border'}"
                    >
                        <span
                            class="absolute top-0.5 size-5 rounded-full bg-white shadow transition-[inset-inline-start] {reserve
                                ? 'start-[22px]'
                                : 'start-0.5'}"
                        ></span>
                    </button>
                </div>

                <!-- المنع والتحذير -->
                {#if blocked}
                    <p class="mt-3 flex items-start gap-2 rounded-xl border border-destructive/35 bg-destructive/8 px-3 py-2.5 text-[12px] font-medium text-destructive">
                        <TriangleAlert class="mt-px size-4 shrink-0" />
                        <span>
                            هذا القسط يرفع التزاماتك إلى {formatCurrency(totalAfter)} وهي أكبر من دخلك
                            ({formatCurrency(income)}) — مدّه على أشهر أكثر أو أنهِ التزاماً قائماً أولاً.
                        </span>
                    </p>
                {:else if warning}
                    <p class="mt-3 flex items-start gap-2 rounded-xl border border-warning/40 bg-warning/10 px-3 py-2.5 text-[12px] text-warning-text">
                        <TriangleAlert class="mt-px size-4 shrink-0" />
                        <span>{warning}</span>
                    </p>
                {/if}
            </div>

            <!-- التذييل الثابت: زر الحفظ لا يغيب عن الشاشة أبداً -->
            <div
                class="shrink-0 border-t border-border bg-card px-4 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))] md:pb-3"
            >
                <div class="flex gap-2">
                    <button
                        type="button"
                        onclick={close}
                        class="inline-flex min-h-12 shrink-0 items-center justify-center rounded-2xl border border-input px-4 text-[13px] text-foreground/85"
                    >
                        إلغاء
                    </button>
                    <button
                        type="button"
                        disabled={processing}
                        onclick={submit}
                        class="inline-flex min-h-12 flex-1 items-center justify-center gap-2 rounded-2xl bg-primary text-[14.5px] font-semibold text-primary-foreground transition-transform active:scale-[.99] disabled:opacity-50"
                    >
                        <Check class="size-[18px]" />
                        {processing ? 'جارٍ الحفظ…' : `حفظ ${KIND_LABEL[kind]}`}
                    </button>
                </div>
            </div>
        </div>
    </div>
{/if}
